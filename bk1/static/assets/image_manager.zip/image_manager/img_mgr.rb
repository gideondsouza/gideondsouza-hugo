require 'sinatra'

get '/' do
  erb :form_multiple
end

post '/upload' do
#this method will get as ajax call for every file uploaded
  @filename = params[:Filename]
  file = params[:Filedata][:tempfile]

  File.open("./public/#{@filename}", 'wb') do |f|
    f.write(file.read)
  end

  #return filename as the response, the file we just wrote.
  return @filename
end
